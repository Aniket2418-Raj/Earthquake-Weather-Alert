# Week 7 — Star Schema Design

**Track A: Earthquake & Weather Alerts | Platform: Microsoft Fabric**

## Grain

One row in the fact table = **one earthquake event, with its matched weather
reading**, sourced from the 3NF tables built in Week 6
(`raw_norm.earthquakes` + `raw_norm.weather_observations`).

## Dimension Tables

### `dim_date`
| Column | Type | Notes |
|---|---|---|
| date_key (PK) | INT | Format YYYYMMDD |
| full_date | DATE | |
| year | INT | |
| quarter | INT | |
| month | INT | |
| month_name | VARCHAR(10) | |
| day | INT | |
| day_of_week | VARCHAR(10) | |
| is_weekend | BIT | |

### `dim_location`
| Column | Type | Notes |
|---|---|---|
| location_key (PK) | INT IDENTITY | |
| latitude | DECIMAL(9,6) | |
| longitude | DECIMAL(9,6) | |
| place | VARCHAR(255) | From USGS `place` |
| region | VARCHAR(100) | Parsed region/country suffix from `place` |

### `dim_magnitude_category`
| Column | Type | Notes |
|---|---|---|
| magnitude_category_key (PK) | INT | |
| category_label | VARCHAR(20) | Minor / Light / Moderate / Strong / Major / Great |
| min_mag | DECIMAL(3,1) | |
| max_mag | DECIMAL(3,1) | |

### `dim_weather_condition`
| Column | Type | Notes |
|---|---|---|
| weather_condition_key (PK) | INT | |
| weathercode | INT | WMO code from Open-Meteo |
| description | VARCHAR(100) | Human-readable label (e.g. "Clear sky") |
| is_day | BIT | |

## Fact Table

### `fact_earthquake_weather`
| Column | Type | Notes |
|---|---|---|
| fact_id (PK) | BIGINT IDENTITY | |
| usgs_event_id | VARCHAR(32) | Degenerate dimension (traces back to source) |
| date_key (FK) | INT | → dim_date |
| location_key (FK) | INT | → dim_location |
| magnitude_category_key (FK) | INT | → dim_magnitude_category |
| weather_condition_key (FK) | INT | → dim_weather_condition |
| event_time_utc | DATETIME2 | |
| magnitude | DECIMAL(3,1) | Measure |
| depth_km | DECIMAL(6,2) | Measure |
| temperature_c | DECIMAL(5,2) | Measure |
| windspeed_kmh | DECIMAL(5,2) | Measure |
| felt_reports | INT | Measure |
| tsunami_flag | BIT | Measure/flag |

## Diagram

```mermaid
erDiagram
    FACT_EARTHQUAKE_WEATHER }o--|| DIM_DATE : "occurred on"
    FACT_EARTHQUAKE_WEATHER }o--|| DIM_LOCATION : "occurred at"
    FACT_EARTHQUAKE_WEATHER }o--|| DIM_MAGNITUDE_CATEGORY : "classified as"
    FACT_EARTHQUAKE_WEATHER }o--|| DIM_WEATHER_CONDITION : "observed with"

    FACT_EARTHQUAKE_WEATHER {
        bigint fact_id PK
        varchar usgs_event_id
        int date_key FK
        int location_key FK
        int magnitude_category_key FK
        int weather_condition_key FK
        datetime2 event_time_utc
        decimal magnitude
        decimal depth_km
        decimal temperature_c
        decimal windspeed_kmh
        int felt_reports
        bit tsunami_flag
    }

    DIM_DATE {
        int date_key PK
        date full_date
        int year
        int quarter
        int month
        varchar month_name
        int day
        varchar day_of_week
        bit is_weekend
    }

    DIM_LOCATION {
        int location_key PK
        decimal latitude
        decimal longitude
        varchar place
        varchar region
    }

    DIM_MAGNITUDE_CATEGORY {
        int magnitude_category_key PK
        varchar category_label
        decimal min_mag
        decimal max_mag
    }

    DIM_WEATHER_CONDITION {
        int weather_condition_key PK
        int weathercode
        varchar description
        bit is_day
    }
```

## Why star schema (denormalized) here

Analytical queries ("average magnitude by region", "earthquake counts by
weather condition", "events per weekend vs weekday") need fast aggregation
across a single fact table joined to small dimension tables — the 3NF model
from Week 6 is optimized for write integrity, not for this kind of scan/join
pattern. Conforming the dimensions (date, location, magnitude bucket,
weather condition) lets the same `dim_date`/`dim_location` be reused if more
fact tables are added later.
