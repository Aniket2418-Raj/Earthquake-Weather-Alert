# Week 7 — Microsoft Fabric Implementation Notes

**Track A: Earthquake & Weather Alerts**

## Architecture

```
landing_zone (raw JSON, Week 5)
        │
        ▼
Bronze Lakehouse tables  (raw JSON loaded as-is, Delta format)
        │  Dataflow Gen2 / Notebook
        ▼
Silver Lakehouse tables  (3NF: silver_earthquakes, silver_weather_observations — Week 6 logic)
        │  Notebook: src/transform_to_star_schema.py
        ▼
Gold Lakehouse tables    (star schema: fact_earthquake_weather + 4 dim tables)
        │
        ▼
Power BI / DirectLake reporting
```

## Dataflow Gen2 (Bronze → Silver)

A **Dataflow Gen2** in the Fabric workspace handles Bronze → Silver:

1. **Source**: connects to the Lakehouse `landing_zone` files (or directly to
   the Bronze Delta table if ingestion already lands there).
2. **Transform (Power Query)**:
   - Expand `features` array from the USGS GeoJSON into rows
   - Expand `geometry.coordinates` into `latitude` / `longitude` / `depth_km` columns
   - Convert `properties.time` / `properties.updated` from epoch ms to datetime
   - Join in the matching Open-Meteo `current_weather` record per event
3. **Destination**: writes to the Silver Lakehouse tables
   `silver_earthquakes` and `silver_weather_observations`, set to
   **Merge (upsert)** on `usgs_event_id`, matching the dedup strategy from
   Week 6.

## Lakehouse Table Ingestion

- All Bronze/Silver/Gold tables are stored as **managed Delta tables** in a
  single Fabric Lakehouse (`earthquake_weather_lh`), so Dataflows, notebooks,
  and Power BI can all read the same underlying files without duplicating data.
- Bronze tables are append-only landing copies of the raw API responses.
- Silver tables enforce the 3NF structure from Week 6.
- Gold tables are the star schema built by `src/transform_to_star_schema.py`,
  run as a Fabric Notebook activity.

## Pipeline orchestration

A **Data Pipeline** in the same workspace chains the steps:

1. Run Week 5 ingestion (`ingest.py`, via a Fabric Notebook or Python activity)
2. Run the Dataflow Gen2 (Bronze → Silver)
3. Run the Notebook `transform_to_star_schema.py` (Silver → Gold)

This pipeline is scheduled in Week 8; for Week 7 it can be run manually to
validate the star schema populates correctly end-to-end.

## Reporting layer

Gold tables are exposed to Power BI via **DirectLake mode**, reading the
Delta files directly from OneLake with no import/refresh step — Power BI
always reflects whatever the last notebook run wrote to
`fact_earthquake_weather` and its dimensions.
