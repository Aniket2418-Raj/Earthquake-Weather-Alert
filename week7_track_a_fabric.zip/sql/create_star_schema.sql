-- ============================================================
-- Week 7 — Star Schema DDL
-- Track A: Earthquake & Weather Alerts
-- Platform: Microsoft Fabric (Fabric Warehouse)
-- ============================================================

CREATE SCHEMA IF NOT EXISTS star;
GO

-- ------------------------------------------------------------
-- DIM_DATE
-- ------------------------------------------------------------
CREATE TABLE star.dim_date (
    date_key        INT           NOT NULL,   -- YYYYMMDD
    full_date       DATE          NOT NULL,
    year            INT           NOT NULL,
    quarter         INT           NOT NULL,
    month           INT           NOT NULL,
    month_name      VARCHAR(10)   NOT NULL,
    day             INT           NOT NULL,
    day_of_week     VARCHAR(10)   NOT NULL,
    is_weekend      BIT           NOT NULL,

    CONSTRAINT PK_dim_date PRIMARY KEY NONCLUSTERED (date_key) NOT ENFORCED
);
GO

-- ------------------------------------------------------------
-- DIM_LOCATION
-- ------------------------------------------------------------
CREATE TABLE star.dim_location (
    location_key    INT IDENTITY(1,1) NOT NULL,
    latitude        DECIMAL(9,6)  NOT NULL,
    longitude       DECIMAL(9,6)  NOT NULL,
    place           VARCHAR(255)  NULL,
    region          VARCHAR(100)  NULL,

    CONSTRAINT PK_dim_location PRIMARY KEY NONCLUSTERED (location_key) NOT ENFORCED
);
GO

-- ------------------------------------------------------------
-- DIM_MAGNITUDE_CATEGORY  (static/seeded dimension)
-- ------------------------------------------------------------
CREATE TABLE star.dim_magnitude_category (
    magnitude_category_key INT           NOT NULL,
    category_label          VARCHAR(20)  NOT NULL,
    min_mag                 DECIMAL(3,1) NOT NULL,
    max_mag                 DECIMAL(3,1) NOT NULL,

    CONSTRAINT PK_dim_magnitude_category PRIMARY KEY NONCLUSTERED (magnitude_category_key) NOT ENFORCED
);
GO

INSERT INTO star.dim_magnitude_category (magnitude_category_key, category_label, min_mag, max_mag) VALUES
    (1, 'Micro',    -9.9, 2.9),
    (2, 'Minor',     3.0, 3.9),
    (3, 'Light',     4.0, 4.9),
    (4, 'Moderate',  5.0, 5.9),
    (5, 'Strong',    6.0, 6.9),
    (6, 'Major',     7.0, 7.9),
    (7, 'Great',      8.0, 9.9);
GO

-- ------------------------------------------------------------
-- DIM_WEATHER_CONDITION
-- ------------------------------------------------------------
CREATE TABLE star.dim_weather_condition (
    weather_condition_key INT           NOT NULL,
    weathercode             INT         NOT NULL,
    description              VARCHAR(100) NOT NULL,
    is_day                    BIT        NOT NULL,

    CONSTRAINT PK_dim_weather_condition PRIMARY KEY NONCLUSTERED (weather_condition_key) NOT ENFORCED
);
GO

-- ------------------------------------------------------------
-- FACT_EARTHQUAKE_WEATHER
-- ------------------------------------------------------------
CREATE TABLE star.fact_earthquake_weather (
    fact_id                  BIGINT IDENTITY(1,1) NOT NULL,
    usgs_event_id            VARCHAR(32)   NOT NULL,   -- degenerate dimension
    date_key                 INT           NOT NULL,
    location_key             INT           NOT NULL,
    magnitude_category_key   INT           NOT NULL,
    weather_condition_key    INT           NULL,
    event_time_utc           DATETIME2     NOT NULL,
    magnitude                DECIMAL(3,1)  NULL,
    depth_km                 DECIMAL(6,2)  NULL,
    temperature_c            DECIMAL(5,2)  NULL,
    windspeed_kmh            DECIMAL(5,2)  NULL,
    felt_reports              INT          NULL,
    tsunami_flag               BIT         NOT NULL DEFAULT 0,

    CONSTRAINT PK_fact_earthquake_weather PRIMARY KEY NONCLUSTERED (fact_id) NOT ENFORCED,
    CONSTRAINT FK_fact_date FOREIGN KEY (date_key)
        REFERENCES star.dim_date (date_key) NOT ENFORCED,
    CONSTRAINT FK_fact_location FOREIGN KEY (location_key)
        REFERENCES star.dim_location (location_key) NOT ENFORCED,
    CONSTRAINT FK_fact_magnitude FOREIGN KEY (magnitude_category_key)
        REFERENCES star.dim_magnitude_category (magnitude_category_key) NOT ENFORCED,
    CONSTRAINT FK_fact_weather FOREIGN KEY (weather_condition_key)
        REFERENCES star.dim_weather_condition (weather_condition_key) NOT ENFORCED
);
GO

CREATE INDEX IX_fact_date ON star.fact_earthquake_weather (date_key);
CREATE INDEX IX_fact_location ON star.fact_earthquake_weather (location_key);
GO
