# Week 7 — Transform 3NF (Silver) -> Star Schema (Gold)
# Track A: Earthquake & Weather Alerts | Platform: Microsoft Fabric
#
# Run this as a Fabric Notebook (PySpark) attached to your Lakehouse.
# Source: Silver Delta tables loaded from the Week 6 3NF SQL tables
#         (raw_norm.earthquakes, raw_norm.weather_observations),
#         mirrored into the Lakehouse as Delta tables silver_earthquakes /
#         silver_weather_observations.
# Target: Gold Delta tables under star schema: fact_earthquake_weather,
#         dim_date, dim_location, dim_magnitude_category,
#         dim_weather_condition.

from pyspark.sql import functions as F
from pyspark.sql import Window
from delta.tables import DeltaTable

LAKEHOUSE_TABLES_PATH = "Tables"  # default Fabric Lakehouse managed table path

# ------------------------------------------------------------
# 1. Read silver (3NF) tables
# ------------------------------------------------------------
silver_eq = spark.read.table("silver_earthquakes")
silver_wx = spark.read.table("silver_weather_observations")

# ------------------------------------------------------------
# 2. Build DIM_DATE (from distinct event dates)
# ------------------------------------------------------------
dim_date = (
    silver_eq
    .select(F.to_date("event_time_utc").alias("full_date"))
    .distinct()
    .withColumn("date_key", F.date_format("full_date", "yyyyMMdd").cast("int"))
    .withColumn("year", F.year("full_date"))
    .withColumn("quarter", F.quarter("full_date"))
    .withColumn("month", F.month("full_date"))
    .withColumn("month_name", F.date_format("full_date", "MMMM"))
    .withColumn("day", F.dayofmonth("full_date"))
    .withColumn("day_of_week", F.date_format("full_date", "EEEE"))
    .withColumn("is_weekend", F.dayofweek("full_date").isin(1, 7))
)

dim_date.write.format("delta").mode("overwrite").saveAsTable("dim_date")

# ------------------------------------------------------------
# 3. Build DIM_LOCATION (distinct lat/lon + place)
# ------------------------------------------------------------
dim_location = (
    silver_eq
    .select("latitude", "longitude", "place")
    .distinct()
    .withColumn(
        "region",
        F.trim(F.element_at(F.split(F.col("place"), ","), -1))
    )
    .withColumn("location_key", F.row_number().over(Window.orderBy("latitude", "longitude")))
)

dim_location.write.format("delta").mode("overwrite").saveAsTable("dim_location")

# ------------------------------------------------------------
# 4. DIM_MAGNITUDE_CATEGORY is a static/seeded dimension.
#    Create it once directly in the Lakehouse (mirrors sql/create_star_schema.sql).
# ------------------------------------------------------------
magnitude_categories = spark.createDataFrame(
    [
        (1, "Micro", -9.9, 2.9),
        (2, "Minor", 3.0, 3.9),
        (3, "Light", 4.0, 4.9),
        (4, "Moderate", 5.0, 5.9),
        (5, "Strong", 6.0, 6.9),
        (6, "Major", 7.0, 7.9),
        (7, "Great", 8.0, 9.9),
    ],
    ["magnitude_category_key", "category_label", "min_mag", "max_mag"],
)
magnitude_categories.write.format("delta").mode("overwrite").saveAsTable("dim_magnitude_category")

# ------------------------------------------------------------
# 5. DIM_WEATHER_CONDITION (distinct WMO weather codes seen so far)
# ------------------------------------------------------------
WMO_DESCRIPTIONS = {
    0: "Clear sky", 1: "Mainly clear", 2: "Partly cloudy", 3: "Overcast",
    45: "Fog", 48: "Depositing rime fog",
    51: "Light drizzle", 53: "Moderate drizzle", 55: "Dense drizzle",
    61: "Slight rain", 63: "Moderate rain", 65: "Heavy rain",
    71: "Slight snow", 73: "Moderate snow", 75: "Heavy snow",
    80: "Rain showers", 95: "Thunderstorm",
}

description_map = F.create_map(
    *[F.lit(x) for pair in WMO_DESCRIPTIONS.items() for x in pair]
)

dim_weather_condition = (
    silver_wx
    .select("weathercode")
    .distinct()
    .withColumn("weather_condition_key", F.row_number().over(Window.orderBy("weathercode")))
    .withColumn("description", F.coalesce(description_map[F.col("weathercode")], F.lit("Unknown")))
    .withColumn("is_day", F.lit(True))  # captured per-observation in the fact grain if needed
)

dim_weather_condition.write.format("delta").mode("overwrite").saveAsTable("dim_weather_condition")

# ------------------------------------------------------------
# 6. Build FACT_EARTHQUAKE_WEATHER
# ------------------------------------------------------------
fact = (
    silver_eq.alias("eq")
    .join(silver_wx.alias("wx"), on="event_id", how="left")
    .withColumn("full_date", F.to_date("eq.event_time_utc"))
    .withColumn("date_key", F.date_format("full_date", "yyyyMMdd").cast("int"))
    .join(dim_location, on=["latitude", "longitude", "place"], how="left")
    .join(
        magnitude_categories,
        (F.col("magnitude") >= F.col("min_mag")) & (F.col("magnitude") <= F.col("max_mag")),
        how="left",
    )
    .join(dim_weather_condition, on="weathercode", how="left")
    .select(
        F.col("eq.usgs_event_id").alias("usgs_event_id"),
        "date_key",
        "location_key",
        "magnitude_category_key",
        "weather_condition_key",
        F.col("eq.event_time_utc").alias("event_time_utc"),
        F.col("eq.magnitude").alias("magnitude"),
        F.col("eq.depth_km").alias("depth_km"),
        F.col("wx.temperature_c").alias("temperature_c"),
        F.col("wx.windspeed_kmh").alias("windspeed_kmh"),
        F.col("eq.felt_reports").alias("felt_reports"),
        F.col("eq.tsunami_flag").alias("tsunami_flag"),
    )
)

# ------------------------------------------------------------
# 7. Idempotent merge into the gold fact table
#    (re-running this notebook must not create duplicate facts)
# ------------------------------------------------------------
if not spark.catalog.tableExists("fact_earthquake_weather"):
    fact.write.format("delta").mode("overwrite").saveAsTable("fact_earthquake_weather")
else:
    target = DeltaTable.forName(spark, "fact_earthquake_weather")
    (
        target.alias("t")
        .merge(fact.alias("s"), "t.usgs_event_id = s.usgs_event_id")
        .whenMatchedUpdateAll()
        .whenNotMatchedInsertAll()
        .execute()
    )

print("Star schema gold tables refreshed: dim_date, dim_location, "
      "dim_magnitude_category, dim_weather_condition, fact_earthquake_weather")
