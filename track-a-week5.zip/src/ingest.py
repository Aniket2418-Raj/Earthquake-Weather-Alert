"""
ingest.py — Week 5 deliverable
Track A: Earthquake & Weather Alerts (Geospatial Data)

Fetches live earthquake data from USGS, enriches each earthquake with
current weather from Open-Meteo, and writes the combined raw payload
to the landing_zone/ folder as timestamped JSON.

This script is intentionally "dumb" — no cleaning, no deduplication,
no schema enforcement. That work belongs in Week 6 (3NF modeling) and
Week 7 (star schema / Fabric implementation). Week 5 is only about
getting reliable raw data onto disk.
"""

import json
import logging
import os
import time
from datetime import datetime, timezone

import requests

# --------------------------------------------------------------------------
# Config
# --------------------------------------------------------------------------

USGS_FEED_URL = "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_day.geojson"
OPEN_METEO_URL = "https://api.open-meteo.com/v1/forecast"

LANDING_ZONE_DIR = os.path.join(os.path.dirname(__file__), "..", "landing_zone")

MAX_RETRIES = 4
INITIAL_BACKOFF_SECONDS = 1.0
REQUEST_TIMEOUT_SECONDS = 10

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)
logger = logging.getLogger("ingest")


# --------------------------------------------------------------------------
# Retry / backoff helper
# --------------------------------------------------------------------------

def fetch_with_retry(url, params=None, max_retries=MAX_RETRIES):
    """
    GET a URL with exponential backoff retry logic.
    Retries on network errors, timeouts, and 429/5xx responses.
    Raises the last exception if all retries are exhausted.
    """
    backoff = INITIAL_BACKOFF_SECONDS
    last_error = None

    for attempt in range(1, max_retries + 1):
        try:
            response = requests.get(url, params=params, timeout=REQUEST_TIMEOUT_SECONDS)

            if response.status_code == 429:
                logger.warning(
                    "Rate limited (429) on attempt %d/%d for %s. Backing off %.1fs.",
                    attempt, max_retries, url, backoff,
                )
                time.sleep(backoff)
                backoff *= 2
                continue

            if response.status_code >= 500:
                logger.warning(
                    "Server error (%d) on attempt %d/%d for %s. Backing off %.1fs.",
                    response.status_code, attempt, max_retries, url, backoff,
                )
                time.sleep(backoff)
                backoff *= 2
                continue

            response.raise_for_status()
            return response.json()

        except (requests.ConnectionError, requests.Timeout) as e:
            last_error = e
            logger.warning(
                "Network error on attempt %d/%d for %s: %s. Backing off %.1fs.",
                attempt, max_retries, url, e, backoff,
            )
            time.sleep(backoff)
            backoff *= 2

    logger.error("Exhausted %d retries for %s", max_retries, url)
    if last_error:
        raise last_error
    raise RuntimeError(f"Failed to fetch {url} after {max_retries} retries")


# --------------------------------------------------------------------------
# Earthquake ingestion
# --------------------------------------------------------------------------

def fetch_earthquakes():
    """Fetch the USGS 'all earthquakes, past day' GeoJSON feed."""
    logger.info("Fetching earthquake data from USGS...")
    data = fetch_with_retry(USGS_FEED_URL)
    features = data.get("features", [])
    logger.info("Retrieved %d earthquake records.", len(features))
    return features


def extract_earthquake_summary(feature):
    """
    Pull the fields we care about out of a USGS GeoJSON feature.
    Note: USGS coordinates are ordered [longitude, latitude, depth].
    """
    props = feature.get("properties", {})
    coords = feature.get("geometry", {}).get("coordinates", [None, None, None])
    longitude, latitude, depth_km = coords[0], coords[1], coords[2]

    return {
        "id": feature.get("id"),
        "magnitude": props.get("mag"),
        "place": props.get("place"),
        "time_epoch_ms": props.get("time"),
        "longitude": longitude,
        "latitude": latitude,
        "depth_km": depth_km,
    }


# --------------------------------------------------------------------------
# Weather enrichment
# --------------------------------------------------------------------------

def fetch_current_weather(latitude, longitude):
    """Fetch current weather for a given lat/lon from Open-Meteo."""
    if latitude is None or longitude is None:
        return None

    params = {
        "latitude": latitude,
        "longitude": longitude,
        "current_weather": True,
    }
    return fetch_with_retry(OPEN_METEO_URL, params=params)


def enrich_earthquakes_with_weather(earthquakes):
    """Attach current weather data to each earthquake record."""
    enriched = []
    for i, eq in enumerate(earthquakes, start=1):
        summary = extract_earthquake_summary(eq)
        logger.info(
            "[%d/%d] Fetching weather for earthquake %s at (%.3f, %.3f)",
            i, len(earthquakes), summary["id"], summary["latitude"] or 0, summary["longitude"] or 0,
        )
        try:
            weather = fetch_current_weather(summary["latitude"], summary["longitude"])
        except Exception as e:
            logger.error("Failed to fetch weather for earthquake %s: %s", summary["id"], e)
            weather = None

        enriched.append({
            "earthquake": summary,
            "weather": weather,
            "raw_earthquake_feature": eq,  # keep the full raw feature too
        })

    return enriched


# --------------------------------------------------------------------------
# Landing zone write
# --------------------------------------------------------------------------

def write_to_landing_zone(records):
    """Write the combined raw payload to landing_zone/ as timestamped JSON."""
    os.makedirs(LANDING_ZONE_DIR, exist_ok=True)

    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H-%M-%S")
    filename = f"earthquakes_{timestamp}.json"
    filepath = os.path.join(LANDING_ZONE_DIR, filename)

    payload = {
        "ingested_at_utc": datetime.now(timezone.utc).isoformat(),
        "source": "USGS + Open-Meteo",
        "record_count": len(records),
        "records": records,
    }

    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)

    logger.info("Wrote %d records to %s", len(records), filepath)
    return filepath


# --------------------------------------------------------------------------
# Main
# --------------------------------------------------------------------------

def main():
    earthquakes = fetch_earthquakes()

    if not earthquakes:
        logger.warning("No earthquake records returned. Nothing to enrich or save.")
        return

    enriched = enrich_earthquakes_with_weather(earthquakes)
    write_to_landing_zone(enriched)


if __name__ == "__main__":
    main()
