# Track A — Earthquake & Weather Alerts (Microsoft Fabric)

## Week 5 — API Ingestion (Python)

This repo currently contains the Week 5 deliverable: a Python ingestion
script that pulls live earthquake data from USGS, enriches each record
with current weather from Open-Meteo, and writes the raw combined
payload to `landing_zone/` as timestamped JSON.

### Setup

    pip install -r requirements.txt
    python src/ingest.py

### Repo structure

    ├── src/            # ingest.py and future transform scripts
    ├── docs/            # ER diagrams, star schema diagrams, architecture docs
    ├── sql/             # create_tables.sql and other SQL scripts (Week 6+)
    ├── landing_zone/    # raw JSON output from ingest.py
    ├── requirements.txt
    └── README.md

### Notes

- Retry/backoff logic handles USGS/Open-Meteo timeouts, 429s, and 5xx errors.
- No cleaning or deduplication happens in Week 5 — raw data only.
- Target cloud platform: Microsoft Fabric (Data Factory + OneLake + DirectLake).
