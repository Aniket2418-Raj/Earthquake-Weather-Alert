"""
Week 6 — Load raw JSON (landing_zone) into 3NF tables
Track A: Earthquake & Weather Alerts
Platform: Microsoft Fabric

This script:
  1. Reads the raw USGS GeoJSON and Open-Meteo JSON files saved by
     Week 5's ingest.py into landing_zone/
  2. Flattens each earthquake feature + its matching weather lookup
  3. Upserts into the Fabric Warehouse tables created by
     sql/create_tables.sql, using MERGE so re-running the pipeline
     never creates duplicate rows (see docs/deduplication_strategy.md)

Connection:
  Uses pyodbc against the Fabric Warehouse SQL connection string.
  Store credentials as environment variables — never hard-code them.

    FABRIC_SQL_SERVER   e.g. xxxxxxxx.datawarehouse.fabric.microsoft.com
    FABRIC_SQL_DATABASE e.g. earthquake_dw
    FABRIC_SQL_CLIENT_ID / FABRIC_SQL_CLIENT_SECRET / FABRIC_SQL_TENANT_ID
        (Azure AD service principal — recommended for Fabric)

Usage:
    python src/load_to_3nf.py --landing-zone landing_zone --batch-id 2026-08-08
"""

import argparse
import datetime as dt
import glob
import json
import logging
import os
import sys
import uuid

import pyodbc

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)
log = logging.getLogger("load_to_3nf")


# ----------------------------------------------------------------
# Connection
# ----------------------------------------------------------------
def get_connection() -> pyodbc.Connection:
    server = os.environ["FABRIC_SQL_SERVER"]
    database = os.environ["FABRIC_SQL_DATABASE"]
    client_id = os.environ["FABRIC_SQL_CLIENT_ID"]
    client_secret = os.environ["FABRIC_SQL_CLIENT_SECRET"]
    tenant_id = os.environ["FABRIC_SQL_TENANT_ID"]

    conn_str = (
        "Driver={ODBC Driver 18 for SQL Server};"
        f"Server={server},1433;"
        f"Database={database};"
        "Encrypt=yes;TrustServerCertificate=no;"
        f"Authentication=ActiveDirectoryServicePrincipal;"
        f"UID={client_id};PWD={client_secret};"
        f"Authority={tenant_id};"
    )
    return pyodbc.connect(conn_str, timeout=30)


# ----------------------------------------------------------------
# Parsing helpers
# ----------------------------------------------------------------
def epoch_ms_to_dt(epoch_ms):
    if epoch_ms is None:
        return None
    return dt.datetime.utcfromtimestamp(epoch_ms / 1000.0)


def load_usgs_features(landing_zone: str):
    """Yield flattened earthquake dicts from every USGS geojson file."""
    pattern = os.path.join(landing_zone, "usgs_*.json")
    for path in sorted(glob.glob(pattern)):
        with open(path, "r", encoding="utf-8") as f:
            payload = json.load(f)
        for feature in payload.get("features", []):
            props = feature.get("properties", {})
            geom = feature.get("geometry", {}) or {}
            coords = geom.get("coordinates", [None, None, None])
            yield {
                "usgs_event_id": feature.get("id"),
                "event_time_utc": epoch_ms_to_dt(props.get("time")),
                "updated_time_utc": epoch_ms_to_dt(props.get("updated")),
                "longitude": coords[0],
                "latitude": coords[1],
                "depth_km": coords[2] if len(coords) > 2 else None,
                "magnitude": props.get("mag"),
                "mag_type": props.get("magType"),
                "place": props.get("place"),
                "event_type": props.get("type"),
                "status": props.get("status"),
                "tsunami_flag": bool(props.get("tsunami")),
                "felt_reports": props.get("felt"),
            }


def load_openmeteo_weather(landing_zone: str, usgs_event_id: str):
    """Load the Open-Meteo current_weather payload matched to one event."""
    path = os.path.join(landing_zone, f"weather_{usgs_event_id}.json")
    if not os.path.exists(path):
        log.warning("No weather file found for event %s", usgs_event_id)
        return None
    with open(path, "r", encoding="utf-8") as f:
        payload = json.load(f)
    cw = payload.get("current_weather")
    if not cw:
        return None
    return {
        "observation_time_utc": cw.get("time"),
        "temperature_c": cw.get("temperature"),
        "windspeed_kmh": cw.get("windspeed"),
        "winddirection_deg": cw.get("winddirection"),
        "weathercode": cw.get("weathercode"),
        "is_day": bool(cw.get("is_day")),
    }


# ----------------------------------------------------------------
# Upsert (dedup) logic — see docs/deduplication_strategy.md
# ----------------------------------------------------------------
MERGE_EARTHQUAKE_SQL = """
MERGE raw_norm.earthquakes AS target
USING (SELECT
    ? AS usgs_event_id, ? AS event_time_utc, ? AS updated_time_utc,
    ? AS latitude, ? AS longitude, ? AS depth_km, ? AS magnitude,
    ? AS mag_type, ? AS place, ? AS event_type, ? AS status,
    ? AS tsunami_flag, ? AS felt_reports
) AS source
ON target.usgs_event_id = source.usgs_event_id
WHEN MATCHED AND source.updated_time_utc > target.updated_time_utc THEN
    UPDATE SET
        event_time_utc = source.event_time_utc,
        updated_time_utc = source.updated_time_utc,
        latitude = source.latitude,
        longitude = source.longitude,
        depth_km = source.depth_km,
        magnitude = source.magnitude,
        mag_type = source.mag_type,
        place = source.place,
        event_type = source.event_type,
        status = source.status,
        tsunami_flag = source.tsunami_flag,
        felt_reports = source.felt_reports
WHEN NOT MATCHED THEN
    INSERT (usgs_event_id, event_time_utc, updated_time_utc, latitude, longitude,
            depth_km, magnitude, mag_type, place, event_type, status,
            tsunami_flag, felt_reports)
    VALUES (source.usgs_event_id, source.event_time_utc, source.updated_time_utc,
            source.latitude, source.longitude, source.depth_km, source.magnitude,
            source.mag_type, source.place, source.event_type, source.status,
            source.tsunami_flag, source.felt_reports)
OUTPUT $action AS action_taken, inserted.event_id;
"""

# Weather readings are append-only per lookup, but we still avoid duplicating
# an identical (event_id, observation_time_utc) pair on pipeline re-runs.
MERGE_WEATHER_SQL = """
MERGE raw_norm.weather_observations AS target
USING (SELECT
    ? AS event_id, ? AS observation_time_utc, ? AS temperature_c,
    ? AS windspeed_kmh, ? AS winddirection_deg, ? AS weathercode, ? AS is_day
) AS source
ON target.event_id = source.event_id
   AND target.observation_time_utc = source.observation_time_utc
WHEN NOT MATCHED THEN
    INSERT (event_id, observation_time_utc, temperature_c, windspeed_kmh,
            winddirection_deg, weathercode, is_day)
    VALUES (source.event_id, source.observation_time_utc, source.temperature_c,
            source.windspeed_kmh, source.winddirection_deg, source.weathercode,
            source.is_day);
"""

INSERT_DQ_LOG_SQL = """
INSERT INTO raw_norm.data_quality_log (event_id, load_batch_id, is_update)
VALUES (?, ?, ?);
"""


def upsert_earthquake(cursor, eq: dict, batch_id: str):
    cursor.execute(
        MERGE_EARTHQUAKE_SQL,
        eq["usgs_event_id"], eq["event_time_utc"], eq["updated_time_utc"],
        eq["latitude"], eq["longitude"], eq["depth_km"], eq["magnitude"],
        eq["mag_type"], eq["place"], eq["event_type"], eq["status"],
        eq["tsunami_flag"], eq["felt_reports"],
    )
    row = cursor.fetchone()
    if row is None:
        # No INSERT/UPDATE happened (record already current) — look up event_id
        cursor.execute(
            "SELECT event_id FROM raw_norm.earthquakes WHERE usgs_event_id = ?",
            eq["usgs_event_id"],
        )
        event_id = cursor.fetchone()[0]
        is_update = False
    else:
        action_taken, event_id = row
        is_update = action_taken == "UPDATE"

    cursor.execute(INSERT_DQ_LOG_SQL, event_id, batch_id, is_update)
    return event_id


def upsert_weather(cursor, event_id: int, weather: dict):
    if weather is None:
        return
    cursor.execute(
        MERGE_WEATHER_SQL,
        event_id, weather["observation_time_utc"], weather["temperature_c"],
        weather["windspeed_kmh"], weather["winddirection_deg"],
        weather["weathercode"], weather["is_day"],
    )


# ----------------------------------------------------------------
# Main
# ----------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(description="Load landing_zone JSON into 3NF tables")
    parser.add_argument("--landing-zone", default="landing_zone")
    parser.add_argument("--batch-id", default=str(uuid.uuid4()))
    args = parser.parse_args()

    log.info("Starting load — batch_id=%s", args.batch_id)

    conn = get_connection()
    conn.autocommit = False
    cursor = conn.cursor()

    inserted, updated, unchanged = 0, 0, 0

    try:
        for eq in load_usgs_features(args.landing_zone):
            if not eq["usgs_event_id"]:
                log.warning("Skipping feature with no id: %s", eq)
                continue

            event_id = upsert_earthquake(cursor, eq, args.batch_id)
            weather = load_openmeteo_weather(args.landing_zone, eq["usgs_event_id"])
            upsert_weather(cursor, event_id, weather)

        conn.commit()
        log.info("Load complete for batch %s", args.batch_id)
    except Exception:
        conn.rollback()
        log.exception("Load failed — transaction rolled back")
        sys.exit(1)
    finally:
        cursor.close()
        conn.close()


if __name__ == "__main__":
    main()
