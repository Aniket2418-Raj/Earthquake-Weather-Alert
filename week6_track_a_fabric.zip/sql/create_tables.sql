-- ============================================================
-- Week 6 — 3NF Table Creation Script
-- Track A: Earthquake & Weather Alerts (Geospatial Data)
-- Platform: Microsoft Fabric (Fabric Warehouse / SQL endpoint)
-- ============================================================
-- Run this against your Fabric Warehouse (or a Lakehouse SQL
-- endpoint that supports DDL) inside the workspace you created
-- in Week 5. Adjust the schema name below if needed.
-- ============================================================

CREATE SCHEMA IF NOT EXISTS raw_norm;
GO

-- ------------------------------------------------------------
-- 1. EARTHQUAKES  (one row per USGS event)
-- ------------------------------------------------------------
CREATE TABLE raw_norm.earthquakes (
    event_id            INT IDENTITY(1,1) NOT NULL,
    usgs_event_id       VARCHAR(32)   NOT NULL,   -- natural key from USGS 'id'
    event_time_utc      DATETIME2     NOT NULL,
    updated_time_utc    DATETIME2     NOT NULL,   -- used for dedup/versioning
    latitude            DECIMAL(9,6)  NOT NULL,
    longitude           DECIMAL(9,6)  NOT NULL,
    depth_km            DECIMAL(6,2)  NULL,
    magnitude           DECIMAL(3,1)  NULL,
    mag_type            VARCHAR(10)   NULL,
    place               VARCHAR(255)  NULL,
    event_type          VARCHAR(20)   NULL,
    status              VARCHAR(20)   NULL,
    tsunami_flag        BIT           NOT NULL DEFAULT 0,
    felt_reports        INT           NULL,

    CONSTRAINT PK_earthquakes PRIMARY KEY NONCLUSTERED (event_id) NOT ENFORCED,
    CONSTRAINT UQ_earthquakes_usgs_id UNIQUE NONCLUSTERED (usgs_event_id) NOT ENFORCED
);
GO

-- ------------------------------------------------------------
-- 2. WEATHER_OBSERVATIONS  (one row per weather lookup)
-- ------------------------------------------------------------
CREATE TABLE raw_norm.weather_observations (
    weather_id           INT IDENTITY(1,1) NOT NULL,
    event_id              INT           NOT NULL,   -- FK -> earthquakes.event_id
    observation_time_utc  DATETIME2     NOT NULL,
    temperature_c         DECIMAL(5,2)  NULL,
    windspeed_kmh         DECIMAL(5,2)  NULL,
    winddirection_deg     INT           NULL,
    weathercode            INT          NULL,
    is_day                 BIT          NULL,

    CONSTRAINT PK_weather_observations PRIMARY KEY NONCLUSTERED (weather_id) NOT ENFORCED,
    CONSTRAINT FK_weather_event FOREIGN KEY (event_id)
        REFERENCES raw_norm.earthquakes (event_id) NOT ENFORCED
);
GO

-- ------------------------------------------------------------
-- 3. DATA_QUALITY_LOG  (load/dedup audit trail, used from Wk8)
-- ------------------------------------------------------------
CREATE TABLE raw_norm.data_quality_log (
    log_id          INT IDENTITY(1,1) NOT NULL,
    event_id        INT           NOT NULL,
    load_batch_id   VARCHAR(50)   NOT NULL,
    loaded_at_utc   DATETIME2     NOT NULL DEFAULT SYSUTCDATETIME(),
    is_update       BIT           NOT NULL DEFAULT 0,

    CONSTRAINT PK_data_quality_log PRIMARY KEY NONCLUSTERED (log_id) NOT ENFORCED,
    CONSTRAINT FK_dq_event FOREIGN KEY (event_id)
        REFERENCES raw_norm.earthquakes (event_id) NOT ENFORCED
);
GO

-- ------------------------------------------------------------
-- Helpful indexes (Fabric Warehouse: NONCLUSTERED only)
-- ------------------------------------------------------------
CREATE INDEX IX_earthquakes_event_time ON raw_norm.earthquakes (event_time_utc);
CREATE INDEX IX_weather_event_id ON raw_norm.weather_observations (event_id);
GO

-- ------------------------------------------------------------
-- NOTE on constraints:
-- Fabric Warehouse currently enforces PRIMARY KEY / FOREIGN KEY /
-- UNIQUE constraints as informational only (NOT ENFORCED). They
-- document the 3NF design and help the query optimizer, but
-- uniqueness/referential integrity must still be guaranteed by
-- the load logic (see src/load_to_3nf.py MERGE statements).
-- ------------------------------------------------------------
