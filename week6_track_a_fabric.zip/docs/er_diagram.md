# Week 6 — 3NF Entity-Relationship Diagram

**Track A: Earthquake & Weather Alerts (Geospatial Data)**
**Platform: Microsoft Fabric**

## Design Notes

The raw data comes from two sources fetched in Week 5:

- **USGS Earthquake API** (GeoJSON `FeatureCollection` → each `feature` is one earthquake event)
- **Open-Meteo Weather API** (JSON object with current weather for a given lat/lon, looked up *per earthquake location*)

To reach **Third Normal Form (3NF)**, the raw nested JSON is split so that:

1. Every non-key attribute depends on the **whole** primary key (2NF)
2. No non-key attribute depends on another non-key attribute (no transitive dependencies — 3NF)

This means earthquake facts (magnitude, depth, place) live in one entity, and the
weather reading taken *for* that earthquake's location/time lives in a separate
entity, linked by a foreign key — because weather attributes (temperature, wind
speed) do not describe the earthquake itself, they describe a location+time
sample that was captured *because of* the earthquake.

## Entities

### `earthquakes`
One row per USGS event (the natural key `usgs_event_id` comes straight from
USGS's `feature.id`, e.g. `"us7000abcd"`).

| Column | Type | Notes |
|---|---|---|
| event_id (PK) | INT IDENTITY | Surrogate key |
| usgs_event_id (UK) | VARCHAR(32) | Natural key from USGS `id` field, used for dedup |
| event_time_utc | DATETIME2 | From `properties.time` (epoch ms → UTC) |
| updated_time_utc | DATETIME2 | From `properties.updated`, used to detect revisions |
| latitude | DECIMAL(9,6) | From `geometry.coordinates[1]` |
| longitude | DECIMAL(9,6) | From `geometry.coordinates[0]` |
| depth_km | DECIMAL(6,2) | From `geometry.coordinates[2]` |
| magnitude | DECIMAL(3,1) | From `properties.mag` |
| mag_type | VARCHAR(10) | From `properties.magType` |
| place | VARCHAR(255) | From `properties.place` |
| event_type | VARCHAR(20) | From `properties.type` (e.g. "earthquake") |
| status | VARCHAR(20) | From `properties.status` (reviewed/automatic) |
| tsunami_flag | BIT | From `properties.tsunami` |
| felt_reports | INT NULL | From `properties.felt` |

### `weather_observations`
One row per weather lookup performed against an earthquake's coordinates.
Kept separate from `earthquakes` because weather attributes are functionally
dependent on **(location, time)**, not on the earthquake's own key attributes
— collapsing them into `earthquakes` would create transitive dependencies.

| Column | Type | Notes |
|---|---|---|
| weather_id (PK) | INT IDENTITY | Surrogate key |
| event_id (FK) | INT | References `earthquakes.event_id` |
| observation_time_utc | DATETIME2 | From Open-Meteo `current_weather.time` |
| temperature_c | DECIMAL(5,2) | From `current_weather.temperature` |
| windspeed_kmh | DECIMAL(5,2) | From `current_weather.windspeed` |
| winddirection_deg | INT | From `current_weather.winddirection` |
| weathercode | INT | From `current_weather.weathercode` (WMO code) |
| is_day | BIT | From `current_weather.is_day` |

### `data_quality_log` (supports Week 8, created now for traceability)

| Column | Type | Notes |
|---|---|---|
| log_id (PK) | INT IDENTITY | Surrogate key |
| event_id (FK) | INT | References `earthquakes.event_id` |
| load_batch_id | VARCHAR(50) | Ingestion run identifier |
| loaded_at_utc | DATETIME2 | When the row was loaded |
| is_update | BIT | 1 if this load updated an existing row, 0 if inserted new |

## Relationship

```mermaid
erDiagram
    EARTHQUAKES ||--o{ WEATHER_OBSERVATIONS : "has weather reading"
    EARTHQUAKES ||--o{ DATA_QUALITY_LOG : "has load record"

    EARTHQUAKES {
        int event_id PK
        varchar usgs_event_id UK
        datetime2 event_time_utc
        datetime2 updated_time_utc
        decimal latitude
        decimal longitude
        decimal depth_km
        decimal magnitude
        varchar mag_type
        varchar place
        varchar event_type
        varchar status
        bit tsunami_flag
        int felt_reports
    }

    WEATHER_OBSERVATIONS {
        int weather_id PK
        int event_id FK
        datetime2 observation_time_utc
        decimal temperature_c
        decimal windspeed_kmh
        int winddirection_deg
        int weathercode
        bit is_day
    }

    DATA_QUALITY_LOG {
        int log_id PK
        int event_id FK
        varchar load_batch_id
        datetime2 loaded_at_utc
        bit is_update
    }
```

## Why this is 3NF

- **1NF**: every column holds a single atomic value (the nested USGS
  `geometry.coordinates` array and Open-Meteo `current_weather` object are
  flattened into scalar columns).
- **2NF**: each table has a single-column surrogate primary key, so partial
  dependency on a composite key isn't possible.
- **3NF**: `weather_observations` is split out of `earthquakes` specifically
  because temperature/wind depend on (location, time), not on the earthquake's
  identity attributes — keeping them together would mean weather columns are
  transitively dependent on `event_id` through location/time rather than
  directly describing the earthquake.
