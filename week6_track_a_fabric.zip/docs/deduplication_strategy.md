# Week 6 — Deduplication Strategy

**Track A: Earthquake & Weather Alerts**

## Why dedup matters here

The USGS earthquake feed is **not append-only**: the same event can appear in
multiple ingestion runs, and its `properties.mag`, `properties.status`, or
location can be **revised** after review (e.g. an automatic magnitude gets
corrected to a reviewed value hours later). If the pipeline runs on a
schedule (as it will in Week 8), naively inserting every fetched record would
create duplicate rows for the same physical earthquake.

## Natural key

Every USGS feature has a globally unique `id` field (e.g. `"us7000abcd"`).
This is stored as `usgs_event_id` in `raw_norm.earthquakes` and is the
**business/natural key** used to detect duplicates — the `event_id` surrogate
key is only used internally for foreign keys.

## Strategy: MERGE (upsert) keyed on natural key + `updated` timestamp

1. For every incoming earthquake record, look up `raw_norm.earthquakes` by
   `usgs_event_id`.
2. **Not found** → `INSERT` a new row.
3. **Found, and the incoming `properties.updated` timestamp is newer** than
   the stored `updated_time_utc` → `UPDATE` the existing row in place (this
   captures magnitude revisions, status changes from `automatic` to
   `reviewed`, etc.).
4. **Found, and the incoming `updated` timestamp is the same or older** →
   skip; the row already reflects the latest known state, so re-inserting
   would create a duplicate.

This is implemented as a single SQL `MERGE` statement
(`sql/create_tables.sql` defines the table, `src/load_to_3nf.py`
`MERGE_EARTHQUAKE_SQL` implements the logic) so the insert-or-update decision
happens atomically per row instead of a separate "check then write" step
that could race across concurrent runs.

## Weather observations

Weather isn't revised the way earthquake metadata is, but re-running the
pipeline against the same landing-zone files should still be idempotent. The
`weather_observations` table dedups on the pair
**(`event_id`, `observation_time_utc`)** — if a weather reading for that exact
earthquake at that exact timestamp already exists, it's skipped rather than
duplicated.

## Auditability

Every insert or update is also written to `raw_norm.data_quality_log` with:
- which `event_id` was touched
- the `load_batch_id` of the run that touched it
- an `is_update` flag distinguishing "new earthquake" from "revised earthquake"

This gives a full audit trail of how often USGS revises events after the
fact, which is useful evidence for the Week 8 governance write-up.

## Edge cases considered

| Case | Handling |
|---|---|
| Same earthquake fetched twice in one run (retry after a transient failure) | `updated_time_utc` unchanged → second attempt is a no-op update, not a duplicate insert |
| USGS deletes a false-detection event | Out of scope for Week 6 (no hard-delete feed); documented as a known limitation, revisited if time allows in Week 8 |
| Weather lookup fails for an event (Open-Meteo error) | `load_openmeteo_weather` returns `None`; earthquake row is still loaded, weather is simply absent until a later run backfills it |
| Clock skew between fetch time and USGS `updated` time | We trust USGS's own `updated` field rather than our local fetch time, since it's the authoritative revision marker |
